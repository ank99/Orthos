// $Id$

package hunspell.merge;

public abstract class HashData {

  public abstract String getHashString();
}
